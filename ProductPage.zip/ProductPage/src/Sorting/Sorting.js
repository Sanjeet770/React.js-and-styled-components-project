import "./Sorting.css";

const Sorting = ({ sortOption, handleSortChange }) => {
  return (
    <div className="sort-options">
      <label className="sortby">Sort By:</label>
      <select className="selection" value={sortOption} onChange={handleSortChange}>
        <option className="text" value="default">Default</option>
        <option className="text" value="priceLowToHigh">Price: Low to High</option>
        <option className="text" value="priceHighToLow">Price: High to Low</option>
      </select>
    </div>
  );
};

export default Sorting;
