import { useState } from "react";

import Navigation from "./Navigation/Nav";
import Products from "./Products/Products";
import products from "./db/data";
import Recommended from "./Recommended/Recommended";
import Sidebar from "./Sidebar/Sidebar";
import Card from "./components/Card";
import "./index.css";
import Pagination from "./Pagination/Pagination";
import Sorting from "./Sorting/Sorting";

function App() {
  const [selectedFilters, setSelectedFilters] = useState({
    category: null,
    color: null,
    price: null,
  });
  const [sortOption, setSortOption] = useState("default");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6; // Number of items to display per page

  // ----------- Input Filter -----------
  const [query, setQuery] = useState("");

  const handleInputChange = (event) => {
    setQuery(event.target.value);
    setCurrentPage(1);
  };

  const filteredItems = products.filter(
    (product) => product.title.toLowerCase().indexOf(query.toLowerCase()) !== -1
  );

  // ----------- Radio Filtering -----------
  const handleChange = (event) => {
    const { name, value } = event.target;
    setSelectedFilters({ ...selectedFilters, [name]: value });
    setCurrentPage(1);
  };

  // ------------ Button Filtering -----------
  const handleClick = (event) => {
    const { name, value } = event.target;
    setSelectedFilters({ ...selectedFilters, [name]: value });
    setCurrentPage(1);
  };

  function filteredData(products, selectedFilters, query) {
    let filteredProducts = products;

    // Filtering Input Items
    if (query) {
      filteredProducts = filteredItems;
    }

    // Sorting
    if (sortOption === "priceLowToHigh") {
      filteredProducts = filteredProducts.sort(
        (a, b) => a.newPrice - b.newPrice
      );
    } else if (sortOption === "priceHighToLow") {
      filteredProducts = filteredProducts.sort(
        (a, b) => b.newPrice - a.newPrice
      );
    }

    // Applying selected filter
    // if (selectedFilters) {
    //   filteredProducts = filteredProducts.filter(
    //     ({ category, color, company, newPrice, title }) =>
    //       category === selected ||
    //       color === selected ||
    //       company === selected ||
    //       newPrice === selected ||
    //       title === selected
    //   );
    // }

    if (selectedFilters.category) {
      filteredProducts = filteredProducts.filter(
        ({ category }) => category === selectedFilters.category
      );
    }
    
    if (selectedFilters.color) {
      filteredProducts = filteredProducts.filter(
        ({ color }) => color === selectedFilters.color
      );
    }

    if (selectedFilters.price) {
      filteredProducts = filteredProducts.filter(
        ({ newPrice }) => newPrice === selectedFilters.price
      );
    }

    return filteredProducts;
  }

  const filteredProducts = filteredData(products, selectedFilters, query);

  // Calculate the total number of pages based on the filtered data
  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);

  // Extract the data for the current page
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedData = filteredProducts.slice(startIndex, endIndex);
  const handlePageChange = (newPage) => {
    setCurrentPage(newPage);
  };

  const handleSortChange = (event) => {
    setSortOption(event.target.value);
  };

  console.log(selectedFilters)

  return (
    <>
      <Sidebar handleChange={handleChange} />
      <Navigation query={query} handleInputChange={handleInputChange} />
      <Recommended handleClick={handleClick} />
      <Sorting sortOption={sortOption} handleSortChange={handleSortChange} />
      <Products
        result={paginatedData.map(
          ({ img, title, star, reviews, prevPrice, newPrice }) => (
            <Card
              key={Math.random()}
              img={img}
              title={title}
              star={star}
              reviews={reviews}
              // prevPrice={prevPrice}
              newPrice={newPrice}
            />
          )
        )}
      />
      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={handlePageChange}
      />
    </>
  );
}

export default App;
